import os
from twilio.rest import Client
from dotenv import load_dotenv

# Load environment variables (if not already loaded)
load_dotenv()

# Retrieve Twilio credentials from environment variables
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
TWILIO_PHONE_NUMBER = os.getenv("TWILIO_PHONE_NUMBER")

# Initialize the Twilio client
client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

def send_sms_notification(contact, sms_message):

    try:
        message = client.messages.create(
            body=sms_message,
            from_=TWILIO_PHONE_NUMBER,
            to=contact
        )
        return message
    except Exception as e:
        print(f"Error sending SMS: {e}")
        return None
