# hospital/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('patient_auth/', views.patient_auth, name='patient_auth'),
    path('', views.homepage, name='homepage'),
    path('data/', views.data_view, name='data'),
    path('patient_form/', views.patient_form, name='patient_form'),
    path('prescriptions/', views.prescriptions_view, name='prescriptions'),
    path('pharmacist_dashboard/', views.pharmacist_dashboard, name='pharmacist_dashboard'),
    path('patient_prescriptions/<int:id>/', views.patient_prescriptions, name='patient_prescriptions'),
    path('doctor_dashboard/', views.doctor_dashboard, name='doctor_dashboard'),
    path('patient_list/', views.patient_list, name='patient_list'),
    path('patient/<int:id>/', views.patient_details, name='patient_details'),
    path('appointment/', views.appointment_booking, name='appointment'),
path('doctor_appointments/', views.doctor_appointments, name='doctor_appointments'),

]
