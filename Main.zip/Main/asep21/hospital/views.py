# hospital/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.contrib import messages
from django.contrib.auth.hashers import make_password, check_password
from functools import wraps
from .models import *
from hospital.sms_utils import send_sms_notification


# Custom login required decorator
def custom_login_required(view_func):
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        if not request.session.get('logged_in'):
            return redirect('login')
        return view_func(request, *args, **kwargs)
    return _wrapped_view

# Hardcoded credentials for doctor login
USERNAME = 'himanshu91082'
PASSWORD = 'himanshu91081'

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        if username == USERNAME and password == PASSWORD:
            request.session['logged_in'] = True
            request.session['username'] = username
            return redirect('doctor_dashboard')
        else:
            messages.error(request, 'Invalid credentials')
    return render(request, 'login.html')

def logout_view(request):
    request.session.flush()
    return redirect('login')

@custom_login_required
def homepage(request):
    username = request.session.get('username')
    return render(request, 'homepage.html', {'username': username})

def patient_auth(request):
    if request.method == 'POST':
        username = request.POST.get('username')  # treated as contact/phone number
        password = request.POST.get('password')
        try:
            patient = Patient.objects.get(contact=username)
            request.session['logged_in'] = True
            request.session['username'] = username
            return redirect('homepage')
        except Patient.DoesNotExist:
            # Create a new patient with minimal information
            patient = Patient.objects.create(
                name=username,
                age=0,
                gender='Other',
                contact=username,
                symptoms='',
                history='',
                medications='',
                allergies='',
            )
            request.session['logged_in'] = True
            request.session['username'] = username
            return redirect('homepage')
    return render(request, 'patient_login.html')

@custom_login_required
def data_view(request):
    patients = Patient.objects.all().order_by('-created_at')
    return render(request, 'data.html', {'patients': patients})

@custom_login_required
def patient_form(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        age = request.POST.get('age')
        gender = request.POST.get('gender')
        contact = request.POST.get('contact')
        symptoms = request.POST.get('symptoms')
        history = request.POST.get('history')
        medications = request.POST.get('medications')
        allergies = request.POST.get('allergies')
        try:
            Patient.objects.create(
                name=name,
                age=age,
                gender=gender,
                contact=contact,
                symptoms=symptoms,
                history=history,
                medications=medications,
                allergies=allergies,
            )
            message = f"Data received and saved for {name}!"
            return render(request, 'patient_form.html', {'message': message})
        except Exception as e:
            error = f"Error while inserting data: {e}"
            return render(request, 'patient_form.html', {'error': error})
    return render(request, 'patient_form.html')

@custom_login_required
def prescriptions_view(request):
    contact = request.session.get('username')
    prescriptions = Prescription.objects.filter(contact=contact).order_by('-prescribed_on')
    return render(request, 'prescriptions.html', {'prescriptions': prescriptions})

@custom_login_required
def pharmacist_dashboard(request):
    patients = Patient.objects.all().order_by('-created_at')
    patients_list = [{'id': patient.id, 'name': patient.name, 'contact': patient.contact} for patient in patients]
    return render(request, 'pharmacist_dashboard.html', {'patients': patients_list})

@custom_login_required
def patient_prescriptions(request, id):
    patient = get_object_or_404(Patient, pk=id)
    prescriptions = Prescription.objects.filter(patient=patient).order_by('-prescribed_on')
    return render(request, 'patient_prescriptions.html', {'prescriptions': prescriptions})

@custom_login_required
def doctor_dashboard(request):
    patients = Patient.objects.all().order_by('-created_at')
    return render(request, 'doctor_dashboard.html', {'patients': patients})

@custom_login_required
def patient_list(request):
    patients = Patient.objects.all().order_by('-created_at')
    patients_list = [{'id': patient.id, 'name': patient.name, 'contact': patient.contact} for patient in patients]
    return render(request, 'patient_list.html', {'patients': patients_list})

@custom_login_required
def patient_details(request, id):
    patient = get_object_or_404(Patient, pk=id)
    if request.method == 'POST':
        medication = request.POST.get('medication')
        dosage = request.POST.get('dosage')
        instructions = request.POST.get('instructions')
        contact = request.POST.get('contact')
        try:
            Prescription.objects.create(
                patient=patient,
                medication=medication,
                dosage=dosage,
                instructions=instructions,
                contact=contact,
            )
            messages.success(request, 'Prescription added successfully!')
            return redirect(reverse('patient_details', args=[id]))
        except Exception as e:
            messages.error(request, f"An error occurred: {e}")
    return render(request, 'patient_details.html', {'patient': patient})


@custom_login_required
def appointment_booking(request):
    if request.method == 'POST':
        appointment_date = request.POST.get('appointment_date')
        appointment_time = request.POST.get('appointment_time')
        message_text = request.POST.get('message')
        patient = get_object_or_404(Patient, contact=request.session.get('username'))

        # Create the appointment
        appointment = Appointment.objects.create(
            patient=patient,
            appointment_date=appointment_date,
            appointment_time=appointment_time,
            message=message_text,
        )

        # Prepare the SMS notification message
        sms_message = (
            f"Hi {patient.name}, your appointment is booked on {appointment_date} at {appointment_time}."
        )

        # Send SMS notification; ensure the phone number is in correct format (E.164)
        send_sms_notification(patient.contact, sms_message)

        messages.success(request, "Appointment booked successfully! A confirmation SMS has been sent.")
        return redirect('homepage')

    return render(request, 'appointment.html')

@custom_login_required
def doctor_appointments(request):
    # Retrieve all appointments, ordered by appointment date and time (newest first)
    appointments = Appointment.objects.all().order_by('-appointment_date', '-appointment_time')
    return render(request, 'doctor_appointments.html', {'appointments': appointments})


